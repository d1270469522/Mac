<?php
/**
 * Created by PhpStorm.
 * User: guiminzhou
 * Date: 2018/10/27
 * Time: 3:23 PM
 */

$appId = '1810270001';
$channelId = '51gnh';
$mobile = '1355283****';
$mobileMd5 = '77ee747c4be4d6453fa316a66e69830e';
$timestamp = '1540524439559';
$sign = "Bravj/5ih6dv81L6DVy4jZyuhJMabLTZ21xcjJ9w+b+UxykgaOz7tx5rdEYO7HgsjAjleukUSsab
FA1v2mxJ7O5sgBeDzSvo4159EuoHdIqrm4l86ZbcNrf4vLsX0kJ77atZ1+qDvtpizX7A1L066HZu
Z53tyPm3Mr75AKQfmdQ=";

$data = compact(
    'appId',
    'channelId',
    'mobile',
    'mobileMd5',
    'timestamp'
);

//拼接数据
$str = urldecode(http_build_query($data));

echo "拼接数据：";
echo $str . "\n";

//读取公钥文件
$publicKey = file_get_contents('51gnh_public_key.pem');

//转换为openssl格式密钥
$res = openssl_get_publickey($publicKey);

//openssl校验：需要指定签名算法为MD5，默认未SHA1
$result = openssl_verify($str, base64_decode($sign), $res, OPENSSL_ALGO_MD5);

//释放资源
openssl_free_key($res);

echo "校验结果：";
echo $result ? 'true' : 'false';
