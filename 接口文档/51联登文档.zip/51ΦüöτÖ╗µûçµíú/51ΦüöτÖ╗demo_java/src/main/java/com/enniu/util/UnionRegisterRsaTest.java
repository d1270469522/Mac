package com.enniu.util;

import java.util.HashMap;
import org.apache.commons.lang3.StringUtils;

/**
 * @author: ehan
 * @company: 北京鼎力创世科技有限公司
 * 联合注册demo
 * 给你花提供给贵司：
 * 1 RSA公钥
 * 2 接口文档和demo
 * 贵司需要提供给给你花：
 * 1 联合注册撞库接口
 * 2 联合注册注册接口
 * 以下例子为撞库接口实现
 **/
public class UnionRegisterRsaTest {

    public static void main(String[] args) throws Exception {
        /**
         * 1.给你花发送给机构的数据，手机号掩码后四位(后四位为*号)，md5为整个手机号md5(不是掩码后md5)
         */
        String appId = "1804100001";
        String channelId = "51gnh";
        String timestamp = "1541071426523";
        String mobile = "1371756****";
        String md5 = "82ad25a39f6e83a198a8fc2a03928a96";
        String sign = "J1k+sp768xqhjP0DvGEz06oEECzq1kCJtjumLGb6uB8tkgG7TFk98dRUxhw0QKqf94r10l2feNiv\njG6s/EuV+ZPayXQEZi8CQvpeRHu5+mwVeNSl2i/ODymjo/CO747TnhHpurYllMx7ts01V16IsMgH\naxZ+ExmKuA/iDV3zmBs=\n";
        /**
         * 2.机构拿到这些数据进行验签
         */
        boolean b = verifySign(appId, channelId, timestamp, mobile, sign, md5);
        System.out.println(b);
        /**
         * 3.验签通过写自己业务
         */
        //写自己业务代码
        //1.撞库
        //2.注册
    }

    /**
     * 验证方法，此方法可以直接复用，生产去掉System，将我们传递的参数传到此方法，直接进行延签即可，也可以自己优化改造
     */
    public static boolean verifySign(String appId, String channelId, String timestamp, String mobile, String sign,
        String mobileMd5) throws Exception {
        HashMap<String, String> paraMap = new HashMap<String, String>();
        paraMap.put("appId", appId);
        paraMap.put("channelId", channelId);
        paraMap.put("timestamp", timestamp);//时间戳
        paraMap.put("mobile", mobile);
        if (StringUtils.isNotBlank(mobileMd5)) {
            paraMap.put("mobileMd5", mobileMd5);
        }
        String data = SortUtils.formatUrlMap(paraMap);
        /** 签名数据 */
        System.out.println("------签名明文排序数据-------------");
        System.out.println(data);
        /** 签名数据 */
        System.out.println("------校验签名结果------------");
        boolean result = RSAUtil.verify(data.getBytes(), Constant.PALT_PUBLIC_KEY, sign);
        /**校验数字签名**/
        System.out.println("" + result);
        System.out.println("----------------------------");
        return result;
    }
}
