<?php
/**
 *  这是接入360贷款导航H5Api PHP版本的demo程序
 *  demo里只是给出各种细节说明，不要用在生产上
 *  如有疑问，联系360贷款导航开发 j-wangyongxin@360.cn
 */

// 1-使用des加密biz_data 0-不加密
define("USE_DES_ENCRYPT", 1);

main();

function main()
{
    //360贷款导航分配
    $app_id = '26';

    //根据具体业务组装数据
    $biz_data = array(
        'pre_orderid' => '6278890717491040256',
        'event' => 'regist',
        'user_flag' => 1,
        'update_time' => "123",
        'regist' => array(
            'mobile' => '18612345678',
        ),
    );

    $biz_data = json_encode($biz_data, JSON_UNESCAPED_UNICODE);
    if (USE_DES_ENCRYPT) {
        //发送给360贷款导航的数据 加密
        //8字节随机字符串，可以是二进制
        $des_key = '12345678';
        $biz_data = '{"update_time":"123","user_flag":1,"regist":{"mobile":"18612345678"},"event":"regist","pre_orderid":"6278890717491040256"}
';
        $request_param = array(
            'method' => 'event.notify',
            'sign_type' => 'RSA',
            'biz_data' => encryptBizData($biz_data, $des_key),
            'biz_enc' => 1,
            'des_key' => encryptDesKey($des_key),
            'app_id' => $app_id,
            'version' => '1.0',
            'format' => 'json',
            'timestamp' => time(),
        );
        $request_param['sign'] = makeSign($request_param);
    } else {
        //发送给360贷款导航的数据 不加密
        $request_param = array(
                'method' => 'event.notify',
                'sign_type' => 'RSA',
                'biz_data' => $biz_data,
                'biz_enc' => 0,
                'app_id' => $app_id,
                'version' => '1.0',
                'format' => 'json',
                'timestamp' => 11111,
        );
        $request_param['sign'] = makeSign($request_param);
    }
    $url = "http://demo.t.360.cn/xdpt/openapi/proxy/hdo";
    $opts = array(
        'http' => array(
            'method' => 'POST',
            'header' => "Content-type:application/json\r\n",
            'content' => json_encode($request_param, JSON_UNESCAPED_UNICODE),
        ),
    );
    $context = stream_context_create($opts);
    $fp = fopen($url, 'r', false, $context);
    $response = '';
    while (false !== ($line = fgets($fp, 4096))) {
        $response .= $line;
    }
    fclose($fp);
    $response = json_decode($response, true);
    print_r($response);
    return;
}



//des加密biz_data 并且 base64编码
function encryptBizData($plain_data, $key)
{
    $cipher = MCRYPT_DES;//des 算法
    $mode = MCRYPT_MODE_ECB;//ECB模式，不需要iv
    $block_size = mcrypt_get_block_size($cipher, $mode);//8字节分块
    $plain_data = pkcs5_pad($plain_data, $block_size);//pkcs5填充成为8字节整数倍
    $cipher_data = mcrypt_encrypt($cipher, $key, $plain_data, $mode);
    return base64_encode($cipher_data);
}

//rsa 公钥加密des_key 并且 base64编码
function encryptDesKey($des_key)
{
    //360贷款导航的公钥
    $pub_key = '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0gXqDS0UHfrX47hxY5U4Q1Bh3
egTBSbwhU+Jin/pflwVIgigYVSID9FOZrV1oW2Bo5kgOhj/V1AYldHLYTcpTvTy6
iYRny5a6lIhLzJy7uGadck/IAfWRK1OQSq+wNx2RjeIA9Yfz7tARt//bnldx+HyX
xExa+PRi8fT5r/S6xwIDAQAB
-----END PUBLIC KEY-----';

    $cipher_txt = '';
    //公钥加密，PKCS1填充
    openssl_public_encrypt($des_key, $cipher_txt, $pub_key, OPENSSL_PKCS1_PADDING);
    return base64_encode($cipher_txt);
}

function pkcs5_pad($text, $blocksize)
{
    $pad = $blocksize - (strlen( $text ) % $blocksize);
    return $text . str_repeat( chr( $pad ), $pad );
}

//rsa 私钥签名
function makeSign($request_param)
{
    ksort($request_param);
    $data = '';
    foreach ($request_param as $key => $val) {
        if ('' === strval($val) || 'sign' == $key) {
            continue;
        }
        $data .= "{$key}={$val}&";
    }
    $data = rtrim($data, '&');
    var_dump($data);
    //合作方的私钥 这是个示例，实际联调需要合作方自己更换，并提供对应公钥给360贷款导航
    $private_key = '-----BEGIN RSA PRIVATE KEY-----
MIICXAIBAAKBgQC3w6p4A6Tk5O4PO5olkNxQGtF6ASEHCxYE7ZPeQvB0ok+dpc45
SYVJp4SJvV3tnYTfp3WMIt7XRlJAWkO+f/J2ZTEV+s6pBd8xDnCmLxXAueT2ZSRJ
v3YkE6z7gClMpkt4J4BejxmWVGaqva7zjP/c7YEiPlMopyBcWN3BJlCZ5wIDAQAB
AoGBAJsglhtSGDUR/NTnH61uqE0HFqbDpTno5eGrHRSXtZ0AF+2hNoGtytLukzgj
n9MjEjQrjVOLbEqWloC0slNydx6EocFzfkpUhvE4PS9G77vq8Dh9KMerIPRO70r2
cKQhOTbIsdg6hk9cn97VnfxyQAzaWbrCtLmyPyMWQOXXeCgBAkEA4wl8pSmhBoa8
F2H6qR0Y9U4yTPvqAouqYMPs27zPGR2P6YwmjxgYS0shS9vSpLf5812uTd7X3eK2
LvISs2Sy5wJBAM80/W0djeqle99tsr3H7RKDBPZo3+CPyH4pQbN0fjWNAdTRseZI
7cx5o9Ay9ZhIL9pdZl679m3gNW/GMzHfAQECQEntYOT29TQG02BZyyEeFG5sE/z1
WnGRwNzZb1rt1BG9iorl0/hsRBzgTetBnQl9zqnsK0G3+lqJ5ADNWkGH3KkCQA+k
3I1kcdaJb/TKf3g8o/WF1tYTzPNTZ7u+uasm3HCGmODMhDXyw6FwfaG2dzxsFtDR
xGzanBxnlSE/QZY+VAECQBwBlw+pCwaNS8evb8593y38uDRH7LE04Q9bv5opAtFI
xADLi9ZGpWjOWTxJVPoQZ37wt8RqTuyYdgqa+zdqlXw=
-----END RSA PRIVATE KEY-----';
    $signature = '';
    $private_id = openssl_pkey_get_private($private_key);
    openssl_sign($data, $signature, $private_id, OPENSSL_ALGO_SHA1);
    return base64_encode($signature);
}