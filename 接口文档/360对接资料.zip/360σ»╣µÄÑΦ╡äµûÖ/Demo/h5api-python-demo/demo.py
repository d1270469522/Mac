# -*- coding:utf-8 -*-

import json
import urllib2
import urllib
import time
import base64

from Crypto.Cipher import PKCS1_v1_5 as cipher_PKCS1_v1_5
from Crypto.Signature import PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA
from pyDes import *

# 1-使用des加密biz_data 0-不加密
USE_DES_ENCRYPT = 0
REQUEST_URL = 'http://demo.t.360.cn/xdpt/openapi/proxy/hdo'

class Demo():
    def h5api(self):
        #360贷款导航分配
        app_id = '26'
        #根据具体业务组装数据
        biz_data = {
            'pre_orderid': '6278890717491040256',
            'event': 'regist',
            'user_flag': 1,
            'update_time': str(int(time.time())),
            'regist': {
                'mobile': '18612345678',
            }
        }

        biz_data = json.dumps(biz_data, ensure_ascii=True, default=str, separators=(',', ':'))
        if USE_DES_ENCRYPT:
            #发送给360贷款导航的数据 加密
            des_key = '12345678'
            request_param = {
                'method': 'event.notify',
                'sign_type': 'RSA',
                'biz_data': encryptBizData(biz_data, des_key),
                'biz_enc': 1,
                'des_key': encryptDesKey(des_key),
                'app_id': app_id,
                'version': '1.0',
                'format': 'json',
                'timestamp': str(int(time.time())),
            }
            request_param['sign'] = makeSign(request_param)
        else:
            #发送给360贷款导航的数据 不加密
            request_param = {
                'method': 'event.notify',
                'sign_type': 'RSA',
                'biz_data': biz_data,
                'biz_enc': 0,
                'app_id': app_id,
                'version': '1.0',
                'format': 'json',
                'timestamp': str(int(time.time())),
            }
            request_param['sign'] = makeSign(request_param)
        request_data = json.dumps(request_param, ensure_ascii=True, default=str, separators=(',', ':'))
        ret = doPost(REQUEST_URL, request_data)
        print ret

def makeSign(param):
    """签名"""
    sign_data = ''
    for param_info in sorted(param.iteritems(), key=lambda d:d[0]):
        sign_data += "%s=%s&" % (param_info[0], param_info[1])

    sign_data = sign_data.rstrip('&')
    sign = '';
    key = RSA.importKey(open('private_key.pem').read())
    h = SHA.new(sign_data)
    signature = PKCS1_v1_5.new(key)
    signature = signature.sign(h)
    sign = base64.b64encode(signature)
    return sign

def encryptBizData(plain_data, key):
    """加密业务数据"""
    k = des(key, ECB, padmode=PAD_PKCS5)
    encrypt_str = k.encrypt(plain_data)
    return base64.b64encode(encrypt_str)

def encryptDesKey(des_key):
    """加密deskey"""
    h = SHA.new(des_key)
    key = RSA.importKey(open('public_key.pem').read())
    cipher = cipher_PKCS1_v1_5.new(key)
    cipher_txt = cipher.encrypt(des_key+h.digest())
    return base64.b64encode(cipher_txt)

def doPost(url, values):
    """发送请求"""
    req = urllib2.Request(url)
    res = urllib2.urlopen(req, values)
    ret = res.read()
    return ret


demo = Demo()
demo.h5api()